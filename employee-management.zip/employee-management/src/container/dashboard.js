import React, { Component } from 'react';

import { addEmployee, removeEmployee, modifyEmployee } from '../utility/utility';

import MaleAvatar from '../assets/Images/male_avatar.png';
import FemaleAvatar from '../assets/Images/female_avatar.png';

import './dashboard.css';

class Dashboard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            employee: [
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
                { name: 'a', desg: 'b', company: 'c', gender: 'M' },
            ],
            edit: false
        }

        this.name = null;
        this.desg = null;
        this.company = null;
        this.gender = null;
    }


    resetEmployeeData = () => {
        this.name = null;
        this.desg = null;
        this.company = null;
        this.gender = null;
    }

    addEmployeeHandler = () => {
        if(this.name && this.desg && this.company && this.gender) {
            let obj = {
                name: this.name,
                desg: this.desg,
                company: this.company,
                gender: this.gender
            }

            this.resetEmployeeData();

            let newArray = addEmployee(this.state.employee, obj);

            this.setState({ employee: newArray });
        } else {
            window.alert("Please enter the employee details correctly");
        }
    
    }

    deleteEmployeeHandler = (index) => {
        let newArray = removeEmployee(index, this.state.employee);

        this.setState({ employee: newArray });
    }


    editEmployeeHandler = () => this.setState((prevState) => ({ edit: !prevState.edit }));

    renameEmployeeHandler = (index) => {
        let { name, desg, company, gender } = this.state.employee[index];
        let obj = {
            name,
            desg,
            company,
            gender
        }
        
        if(this.name !== null && name !== this.name) {
            obj.name = this.name
        }
        if(this.desg !== null && desg !== this.desg) {
            obj.desg = this.desg
        }
        if(this.company !== null && company !== this.company) {
            obj.company = this.company
        }
        if(gender !== this.gender) {

        }

        this.resetEmployeeData();

        let newArray = modifyEmployee(this.state.employee, index, obj);

        this.setState((prevState) => ({
            employee: newArray,
            edit: !prevState.edit
        }));
    }

    renderEmployeeForm = () => (
            <div className="dashboard-form--styling">
                <input 
                    type="text" 
                    placeholder="Enter Name" 
                    onChange={(e) => {this.name = e.target.value} } /> {' '}
                <input 
                    type="text" 
                    placeholder="Enter Designation" 
                    onChange={(e) => {this.desg = e.target.value} }/> {' '}
                <input 
                    type="text" 
                    placeholder="Enter Company"
                    onChange={(e) => {this.company = e.target.value} }/> {' '}
                <div className="dashboard-form--styling--radio"> 
                    <input 
                        type="radio" 
                        value="M" 
                        name="gender" 
                        onChange={(e) => {this.gender = e.target.value} }/> 
                    <span>Male</span>&nbsp; 
                    <input 
                        type="radio" 
                        value="F" 
                        name="gender"
                        onChange={(e) => {this.gender = e.target.value} }/> 
                    <span>Female</span>
                </div>
                <button type="submit" value="Submit" onClick={this.addEmployeeHandler}> ADD </button>
            </div>
    );

    renderCompanyEmployees = () => {
        return (this.state.employee.map((employee, index) => {
            return (
                <div key={index} className="dashboard-employee--card">
                    <div className="dashboard-employee--card--details">
                        <img src={employee.gender === 'M' ? MaleAvatar : FemaleAvatar} alt="avatar" height="176px" width="176px"/>
                        {this.state.edit ? <input 
                                    type="text" 
                                    placeholder="Enter Name" 
                                    onChange={(e) => {this.name = e.target.value} } /> : <h3>{employee.name}</h3>}
                        {this.state.edit ? <input 
                                    type="text" 
                                    placeholder="Enter Designation" 
                                    onChange={(e) => {this.desg = e.target.value} }/> : <h4>{employee.desg}</h4> }
                        {this.state.edit ? <input 
                                    type="text" 
                                    placeholder="Enter Company"
                                    onChange={(e) => {this.company = e.target.value} }/> : <h3>{employee.company}</h3> }
                    </div>
                    <div className="dashboard-employee--card--btn">
                        {this.state.edit ? 
                            <img 
                                src="https://img.icons8.com/color/48/000000/checked-2.png"
                                alt="edit" 
                                height="20px" 
                                width="20px" 
                                onClick={() => this.renameEmployeeHandler(index)}/> : null}
                        {!this.state.edit ? 
                            <img 
                                src="https://img.icons8.com/cotton/64/000000/edit--v1.png" 
                                alt="edit" 
                                height="20px" 
                                width="20px" 
                                onClick={this.editEmployeeHandler}/> :
                        <img 
                            src="https://img.icons8.com/flat_round/64/000000/delete-sign.png" 
                            alt="delete" 
                            height="20px" 
                            width="20px" 
                            onClick={this.editEmployeeHandler}/>}
                        <img 
                            src="https://img.icons8.com/color/48/000000/delete-forever.png"
                            alt="delete" 
                            height="20px" 
                            width="20px" 
                            onClick={() => this.deleteEmployeeHandler(index)}/>
                    </div>
                </div>
            );
        }));
    };

    render() {

        return (
            <div className="dashboard">
                <div className='dashboard-form'>
                    {this.renderEmployeeForm()}
                </div>
                <div className="dashboard-employee">
                    {this.renderCompanyEmployees()}
                </div>
            </div>
        );
    }
}

export default Dashboard;

function app() {

}