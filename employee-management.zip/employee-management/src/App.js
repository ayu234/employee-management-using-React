import Dashboard from './container/dashboard';
import './App.css';

function App() {
  return (
    <div>
      <Dashboard />
    </div>
  );
}

export default App;
