export const addEmployee = (employeeArray, employee) => {
    const { id, name, desg, company, gender } = employee;
    let obj = {
        id,
        name,
        desg,
        company,
        gender
    };

    employeeArray.push(obj);

    return employeeArray;
}

export const removeEmployee = (id, employeeArray) => {
    employeeArray.splice(id, 1);
    return employeeArray;
}

export const modifyEmployee = (employeeArray, id, employee) => {
    employeeArray[id] = employee;

    return employeeArray;
}